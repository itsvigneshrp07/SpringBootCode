package com.st.hrms.util;

import java.util.ArrayList;
import java.util.List;

public class LeaveType {
	public static List<String> getLeaveTypes() {
		List<String> list = new ArrayList<String>();
		list.add("Sick Leave");
		list.add("Casual Leave");
		return list;
	}
}
