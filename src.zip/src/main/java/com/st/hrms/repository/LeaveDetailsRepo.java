package com.st.hrms.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.LeaveDetails;

@Repository
public interface LeaveDetailsRepo extends JpaRepository<LeaveDetails, Long> {

	@Query("Select a from LeaveDetails a where a.empId=:empId and :startDate >= a.startDate and :endDate <= a.endDate")
	List<LeaveDetails> getLeaveDetails(@Param("empId") String empId, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

	@Query("Select a from LeaveDetails a where a.empId=:empId and a.status=:status")
	List<LeaveDetails> getEmplLeaveDetails(@Param("empId") String empId, @Param("status") String status);

	@Query("Select a from LeaveDetails a where a.empId=:empId")
	List<LeaveDetails> findByEmpId(@Param("empId") String empId);

}