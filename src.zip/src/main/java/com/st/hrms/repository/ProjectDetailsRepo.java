package com.st.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.ProjectDetails;

@Repository
public interface ProjectDetailsRepo extends JpaRepository<ProjectDetails, Long> {

	ProjectDetails findByProjectId(String projectId);
	
	ProjectDetails findByProjectName(String projectName);

	@Query("delete from ProjectDetails a where a.projectId = :projectId")
	void deleteByProjectId(String projectId);

}