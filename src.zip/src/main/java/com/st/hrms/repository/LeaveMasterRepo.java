package com.st.hrms.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.LeaveMaster;

@Repository
public interface LeaveMasterRepo extends JpaRepository<LeaveMaster, Long> {

	// List<LeaveMaster> findByStartDateAndEndDate(@Param("startDate") Date
	// startDate, @Param("endDate") Date endDate);

	@Query("Select a from LeaveMaster a where a.startDate = :startDate and a.endDate = :endDate and a.leaveType =:leaveType")
	LeaveMaster findByLeaveTypeStartDateEndDate(@Param("leaveType") String leaveType,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query("Select a from LeaveMaster a where a.startDate = :startDate and a.endDate = :endDate")
	List<LeaveMaster> getLeaveTypes(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

}