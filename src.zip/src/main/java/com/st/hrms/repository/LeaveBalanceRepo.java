package com.st.hrms.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.LeaveBalance;

@Repository
public interface LeaveBalanceRepo extends JpaRepository<LeaveBalance, Long> {

	@Query("Select a from LeaveBalance a where a.empId= :empId and :startDate >= a.startDate and :endDate <= a.endDate and a.leaveType= :leaveType")
	public LeaveBalance findCountByEmpIdLeaveTypeSDateEDate(@Param("empId") String empId,
			@Param("leaveType") String leaveType, @Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query("Select a from LeaveBalance a where a.empId= :empId and a.leaveType=:leaveType and a.lock <> 1")
	public LeaveBalance findCountByEmpIdLeaveType(@Param("empId") String empId, @Param("leaveType") String leaveType);

	@Query("Select a from LeaveBalance a where a.empId= :empId and :startDate >= a.startDate and :endDate <= a.endDate")
	public List<LeaveBalance> findCountByEmpIdSDateEDate(@Param("empId") String empId,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);

}
