package com.st.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.Address;

@Repository
public interface AddressRepository extends JpaRepository<Address, Long> {

}