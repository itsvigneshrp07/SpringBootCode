package com.st.hrms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.Education;

@Repository
public interface EducationRepository extends JpaRepository<Education, Long> {

	public List<Education> findByEmployeeID(String employeeID);

}
