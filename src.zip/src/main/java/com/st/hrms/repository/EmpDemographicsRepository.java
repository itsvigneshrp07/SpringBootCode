package com.st.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.EmpDemographics;

@Repository
public interface EmpDemographicsRepository extends JpaRepository<EmpDemographics, Long> {

}
