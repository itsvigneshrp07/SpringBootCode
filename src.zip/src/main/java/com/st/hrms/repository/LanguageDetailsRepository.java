package com.st.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.st.hrms.models.LanguageDetails;

@Repository
public interface LanguageDetailsRepository extends JpaRepository<LanguageDetails, Long> {

}
