package com.st.hrms.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.st.hrms.models.Timesheet;

@Repository
public interface TimesheetRepository extends JpaRepository<Timesheet, Long> {

	List<Timesheet> findByEmpId(String empId);
	
	@Query("Select a from Timesheet a where a.empId= :empId and a.workDate >= :startDate and a.workDate<= :endDate")
	List<Timesheet> findByEmpIdStartDateEndDATE(@RequestParam("empId") String empId, @RequestParam ("startDate") Date startDate,@RequestParam("endDate")  Date endDate);
	
	@Query("delete from Timesheet a where a.empId = :empId")
	void deleteByEmpId(@RequestParam ("empId") String empId);
	
}
