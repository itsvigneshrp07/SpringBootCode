package com.st.hrms.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "EDUCATION")
public class Education {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "employeeID", nullable = false)
	private String employeeID;

	@Column(name = "level", nullable = false)
	private String level;

	@Column(name = "branch")
	private String branch;

	@Column(name = "school", nullable = false)
	private String school;

	@Column(name = "university", nullable = false)
	private String university;

	@Column(name = "place", nullable = false)
	private String place;

	@Column(name = "state", nullable = false)
	private String state;

	@Column(name = "country")
	private String country;

	@Column(name = "yearOfPassing", nullable = false)
	private Date yearOfPassing;

	@Column(name = "percentage", nullable = false)
	private String percentage;

}
