package com.st.hrms.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "Language_Details")
public class LanguageDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "id", updatable = true, nullable = false)
	// @Min(value = 0L, message = "The value must be positive")
	private Long id;

	@Column(length = 10, name = "empId")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "empId variable is empty")
	private String empId;

	@Column(length = 100, name = "lan_name1")
	@Size(min = 2, max = 110, message = " Enter your Provided EmployeeId (max value 100)")
	// @NotBlank(message = "lan_name1 variable is empty")
	private String lan_name1;

	@Column(length = 100, name = "lan_name2")
	@Size(min = 2, max = 100, message = " Enter your Provided EmployeeId (max value 100)")
	// @NotBlank(message = "lan_name2 variable is empty")
	private String lan_name2;

	@Column(length = 100, name = "lan_name3")
	@Size(min = 2, max = 100, message = " Enter your Provided EmployeeId (max value 100)")
	// @NotBlank(message = "lan_name3 variable is empty")
	private String lan_name3;

	@Column(length = 3, name = "mothertongue")
	@Size(min = 2, max = 3, message = " Enter your Provided EmployeeId (max value 3)")
	// @NotBlank(message = "mothertongue variable is empty")
	private String mothertongue;

	@Column(length = 10, name = "speakks1")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "speakks1 variable is empty")
	private String speakks1;

	@Column(length = 10, name = "speakks2")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "speakks2 variable is empty")
	private String speakks2;

	@Column(length = 10, name = "speakks3")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "speakks3 variable is empty")
	private String speakks3;

	@Column(length = 10, name = "writees1")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "writees1 variable is empty")
	private String writees1;

	@Column(length = 10, name = "writees2")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "writees2 variable is empty")
	private String writees2;

	@Column(length = 10, name = "writees3")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "writees3 variable is empty")
	private String writees3;

	@Column(length = 10, name = "readds1")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "readds1 variable is empty")
	private String readds1;

	@Column(length = 10, name = "readds2")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "readds2 variable is empty")
	private String readds2;

	@Column(length = 10, name = "readds3")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "readds3 variable is empty")
	private String readds3;

}
