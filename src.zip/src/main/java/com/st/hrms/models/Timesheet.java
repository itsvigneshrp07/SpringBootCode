package com.st.hrms.models;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "TIMESHEET")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Timesheet implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "EmpId variable is empty")
	@Column(name = "EMP_ID", nullable = false)
	private String empId;

	@Column(name = "PROJECT_NAME")
	private String projectName;
	
	@Column(name = "PROJECT_ID")
	private String projectId;

	@Column(name = "TASK_NAME")
	private String taskName;

	@Column(name = "TASK_ID")
	private String taskId;
	
	@Column(name = "WORK_DATE")
	private Date workDate;
	
	@Column(name = "HOURS")
	private Long hours;
	
	@Column(name = "COMMENT")
	private String comment;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "SUBMITTED_DATE")
	private Date submittedDate;

}
