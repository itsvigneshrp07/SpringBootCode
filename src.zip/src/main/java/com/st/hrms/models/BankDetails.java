package com.st.hrms.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "Bank_B_details")
public class BankDetails implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "brole_id", updatable = true, nullable = false)
	private Long brole_id;

	@Column(length = 10, name = "empId")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "empId variable is empty")
	private String empId;

	@Column(length = 80, name = "bank_name")
	@Size(min = 2, max = 80, message = " you should enter atleast 2 char value  but not more then 80 (max value 80)")
	// @NotBlank(message = "bank_name variable is empty")
	private String bank_name;

	@Column(length = 80, name = "bank_type")
	@Size(min = 2, max = 80, message = " you should enter atleast 2 char value  but not more then 80 (max value 80)")
	// @NotBlank(message = "bank_Type variable is empty")
	private String bank_type;

	@Column(length = 50, name = "acc_holdername")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	// @NotBlank(message = "acc_holdername variable is empty")
	private String acc_holdername;

	@Column(name = "acc_no")
	// @NotBlank(message = "acc_no variable is empty")
	private String acc_no;

	@Column(length = 15, name = "ifsc_code")
	@Size(min = 2, max = 15, message = " you should enter atleast 2 char value  but not more then 15 (max value 15)")
	// @NotBlank(message = "ifsc_code variable is empty")
	private String ifsc_code;

	@Column(length = 80, name = "bank_branch")
	@Size(min = 2, max = 80, message = " you should enter atleast 2 char value  but not more then 80 (max value 80)")
	// @NotBlank(message = "bank_branch variable is empty")
	private String bank_branch;

	@Column(length = 110, name = "b_address")
	@Size(min = 2, max = 110, message = " you should enter atleast 2 char value  but not more then 110 (max value 110)")
	// @NotBlank(message = "b_address variable is empty")
	private String b_address;

	@Column(length = 10, name = "pincode")
	@Size(min = 2, max = 10, message = " you should enter atleast 2 char value  but not more then 10 (max value 10)")
	// @NotBlank(message = "pincode variable is empty")
	private String pincode;

	// @ManyToOne

	// @JoinColumn(name = "empId",nullable = true )
//	// @OnDelete(action = OnDeleteAction.CASCADE)
//	 @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)

	// private Employee employee;

}
