package com.st.hrms.models;

public enum LeaveType {
	SICKLEAVE, CASUALLEAVE
}
