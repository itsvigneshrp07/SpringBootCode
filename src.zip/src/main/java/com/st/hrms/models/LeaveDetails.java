package com.st.hrms.models;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "LEAVE_DETAILS")
public class LeaveDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long leaveDetailId;

	@Column(name = "EMP_ID")
	private String empId;

	@Column(name = "APPLIED_DATE")
	private Date appliedDate;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "END_DATE")
	private Date endDate;

	@Column(length = 25, name = "POC")
	private String pointOfContact;

	@Column(name = "LEAVE_TYPE")
	private String leaveType;

	@Column(length = 65, name = "COMMENTS")
	private String comments;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "LOCKED", columnDefinition = "integer default 0")
	private int locked;

}
