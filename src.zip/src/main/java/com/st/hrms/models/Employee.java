package com.st.hrms.models;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "Employee")
public class Employee implements Serializable {

	
	
	@Id
	// @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	// @GenericGenerator(name = "native", strategy = "native")
	@Column(name = "empId", updatable = true, nullable = false)
	// @Min(value = 0L, message = "The value must be positive")
	private String empId;

//	@Column(length = 7 ,name = "OrgId")
//	@NotBlank(message = "OrgId  variable is empty")
//	@Size(min = 1, max = 7,message = " you should enter atleast 1 char value  but not more then 7 (max value 7)" )
//	private String orgId;

	@Column(name = "date_of_joining")
	// @PastOrPresent
	// @NotBlank(message = "date_of_joining variable is empty")
	private Date date_of_joining;

	@Column(length = 25, name = "department")
	@Size(min = 2, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 7)")
	// @NotBlank(message = "department variable is empty")
	private String department;

	@Column(length = 25, name = "fName")
	@Size(min = 2, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 7)")
	// @NotBlank(message = "fName variable is empty")
	private String fname;

	@Column(length = 25, name = "mName")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 7)")
	private String mname;

	@Column(length = 25, name = "lName")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 7)")
	// @NotBlank(message = "lName variable is empty")
	private String lname;

	@Column(length = 6, name = "gender")
	@Size(min = 1, max = 6, message = " you should enter atleast 1 char value  but not more then 6 (max value 7)")
	// @NotBlank(message = "gender variable is empty")
	private String gender;

	@Column(name = "dob")
	// @PastOrPresent
	private Date dateofbirth;

	@Column(name = "Official_email")
	@Email(message = "Please provide a valid email address")
	@Pattern(regexp = ".+@.+\\..+", message = "Please provide a Official_email  address")
	// @NotBlank(message = "Official_email variable is empty")
	private String official_email;

	@Column(name = "Personl_email")
	@Email(message = "Please provide a valid email address")
	@Pattern(regexp = ".+@.+\\..+", message = "Please provide a valid Personl_email address")
	// @NotBlank(message = "Personl_email variable is empty")
	private String personal_email;

	@Column(name = "Official_mobile_no")
	@Min(value = 0L, message = "The value must be positive")

	// @Range(min = 10,max= 12, message = "phone_no should be exact 10-12
	// characters." )
	private Long official_mobile_no;

	@Column(name = "Personl_mobile_no")
	@Min(value = 0L, message = "The value must be positive")
	// @Range(min = 10,max= 12, message = "phone_no should be exact 10-12 digites."
	// )
	private Long personal_mobile_no;

//	@Column(name = "WorkExperience")
//	@Min(value = 0L, message = "The value must be positive")
//	//@NotNull(message = "WorkExperience  variable is empty.you should enter your WorkExperience ")
//	private Long workExperience;

//	@Column(name = "salary")
//	@PositiveOrZero
//	private Double salary;

//	@Column(length = 80 ,name = "company")
//	@Size(min = 1, max = 80,message = " you should enter atleast 1 char value  but not more then 80 (max value 7)")
//	//@NotBlank(message = "company  variable is empty.Enter company name")
//	private String company;

	@Column(name = "active")
	// @NotBlank(message = "active variable is empty;allowed input: true or false")
	// @AssertTrue

	private boolean active;

//	@OneToMany(mappedBy = "employee",cascade = CascadeType.ALL )
//	@JsonIgnore
//	private Set<Bank_B_details> Bank_B_details= new HashSet<>();;

}
