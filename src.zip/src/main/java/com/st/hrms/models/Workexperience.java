package com.st.hrms.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "Workexperience")
public class Workexperience {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "id", updatable = true, nullable = false)
	// @Min(value = 0L, message = "The value must be positive")
	private Long id;

	@Column(length = 10, name = "empId")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "empId variable is empty")
	private String empId;

	@Column(name = "totel_workexperience")

	// @NotBlank(message = "totel_workexperience variable is empty")
	private String total_workexperience;

	@Column(length = 90, name = "org_name1")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "org_name1 variable is empty")
	private String org_name1;

	@Column(length = 90, name = "org_name2")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "org_name2 variable is empty")
	private String org_name2;

	@Column(length = 90, name = "org_name3")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "org_name3 variable is empty")
	private String org_name3;

	@Column(length = 90, name = "reference_name")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "reference_name variable is empty")
	private String reference_name;

	@Column(length = 90, name = "reference_name1")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "reference_name1 variable is empty")
	private String reference_name1;

	@Column(length = 90, name = "reference_name2")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "reference_name2 variable is empty")
	private String reference_name2;

	@Column(length = 90, name = "reference_email")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "orgName variable is empty")
	private String reference_email;

	@Column(length = 90, name = "reference_email1")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "reference_email1 variable is empty")
	private String reference_email1;

	@Column(length = 90, name = "reference_email2")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "reference_email2 variable is empty")
	private String reference_email2;

	@Column(length = 90, name = "reference_contact")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "orgName variable is empty")
	private String reference_contact;

	@Column(length = 90, name = "reference_contact1")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "orgName variable is empty")
	private String reference_contact1;

	@Column(length = 90, name = "reference_contact3")
	@Size(min = 2, max = 90, message = " Enter your Provided EmployeeId (max value 90)")
	// @NotBlank(message = "orgName variable is empty")
	private String reference_contact3;

	@Column(name = "from_joining_date")
	// @PastOrPresent
	// @NotBlank(message = "from_joining_date variable is empty")
	private Date from_joining_date;

	@Column(name = "from_end_date")
	// @PastOrPresent
	// @NotBlank(message = "from_joining_date variable is empty")
	private Date from_end_date;

	@Column(length = 80, name = "designation")
	@Size(min = 2, max = 80, message = " Enter your Provided EmployeeId (max value 80)")
	// @NotBlank(message = "orgName variable is empty")
	private String designation;

	@Column(name = "ctc")
	private Double ctc;

	@Column(length = 120, name = "reason_of_leaving")
	@Size(min = 2, max = 120, message = " Enter your Provided EmployeeId (max value 120)")
	// @NotBlank(message = "reason_of_leaving variable is empty")
	private String reason_of_leaving;

}
