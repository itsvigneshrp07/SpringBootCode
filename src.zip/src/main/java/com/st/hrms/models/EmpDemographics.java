package com.st.hrms.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "EmpDemographics")
public class EmpDemographics {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "Id", updatable = true, nullable = false)
	// @Min(value = 0L, message = "The value must be positive")
	private Long Id;

	@Column(length = 10, name = "empId")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "empId variable is empty")
	private String empId;

	@Column(length = 25, name = "f_name")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 25)")
	private String f_name;

	@Column(length = 25, name = "m_name")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 25)")
	private String m_name;

	@Column(length = 25, name = "l_name")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 25)")
	private String l_name;

	@Column(length = 25, name = "department")
	@Size(min = 2, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 7)")
	// @NotBlank(message = "department variable is empty")
	private String department;

	@Column(name = "personal_mobile_no")
	@Min(value = 0L, message = "The value must be positive")
	// @Range(min = 10,max= 12, message = "phone_no should be exact 10-12
	// characters." )
	private Long personal_mobile_no;

	@Column(length = 25, name = "place_Of_Birth")
	@Size(min = 1, max = 25, message = " you should enter atleast 2 char value  but not more then 25 (max value 25)")
	private String place_Of_Birth;

	@Column(length = 15, name = "adhar_no")
	@Size(min = 1, max = 15, message = " you should enter atleast 2  value  but not more then 15 (max value 15)")
	private String adhar_no;

	@Column(length = 15, name = "pan_no")
	@Size(min = 1, max = 15, message = " you should enter atleast 2  value  but not more then 15 (max value 15)")
	private String pan_no;

	@Column(length = 20, name = "passPort_no")
	@Size(min = 1, max = 20, message = " you should enter atleast 2  value  but not more then 20 (max value 20)")
	private String passPort_no;

	@Column(name = "personal_email")
	@Email(message = "Please provide a valid email address")
	@Pattern(regexp = ".+@.+\\..+", message = "Please provide a valid Personl_email address")
	// @NotBlank(message = "Personl_email variable is empty")
	private String personal_email;

	@Column(length = 6, name = "gender")
	@Size(min = 1, max = 6, message = " you should enter atleast 1 char value  but not more then 6 (max value 6)")
	// @NotBlank(message = "gender variable is empty")
	private String gender;

	@Column(length = 25, name = "religion")
	@Size(min = 1, max = 25, message = " you should enter atleast 2  value  but not more then 25 (max value 25)")
	private String religion;

	@Column(length = 20, name = "marital_Status")
	@Size(min = 1, max = 20, message = " you should enter atleast 2  value  but not more then 20 (max value 20)")
	private String marital_Status;

	@Column(length = 10, name = "bloodgroup")
	@Size(min = 1, max = 10, message = " you should enter atleast 2  value  but not more then 20 (max value 10)")
	private String bloodgroup;

	@Column(name = "active")
	// @NotBlank(message = "active variable is empty;allowed input: true or false")
	// @AssertTrue

	private boolean active;
}
