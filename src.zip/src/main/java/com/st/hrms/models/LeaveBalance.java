package com.st.hrms.models;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Entity
@Table(name = "LEAVE_BALANCE")
public class LeaveBalance implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long leaveBalanceId;

	@Column(name = "EMP_ID")
	// @NotNull(message = "*Set employee id")
	private String empId;

	@Column(name = "COUNT")
	private int count;

	@Column(name = "LEAVE_TYPE")
	private String leaveType;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "END_DATE")
	private Date endDate;

	@Column(name = "LOCKED", columnDefinition = "integer default 0")
	private int lock;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

}
