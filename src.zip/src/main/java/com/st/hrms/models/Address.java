package com.st.hrms.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "Address")
public class Address implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "addid", updatable = true, nullable = false)
	private Long addid;

	@Column(length = 10, name = "empId")
	@Size(min = 2, max = 10, message = " Enter your Provided EmployeeId (max value 10)")
	// @NotBlank(message = "empId variable is empty")
	private String empId;

	@Column(length = 50, name = "address_type")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String address_type;

	@Column(length = 50, name = "address1")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String address1;

	@Column(length = 50, name = "address2")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String address2;

	@Column(length = 50, name = "address3")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String address3;

	@Column(length = 50, name = "address4")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String address4;

	@Column(length = 80, name = "place")
	@Size(min = 2, max = 80, message = " you should enter atleast 2 char value  but not more then 80 (max value 80)")
	private String place;

	@Column(length = 50, name = "district")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String district;

	@Column(length = 50, name = "state")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String state;

	@Column(length = 10, name = "pincode")
	@Size(min = 2, max = 10, message = " you should enter atleast 2 char value  but not more then 10 (max value 10)")
	private String pincode;

	@Column(length = 50, name = "country")
	@Size(min = 2, max = 50, message = " you should enter atleast 2 char value  but not more then 50 (max value 50)")
	private String country;

	// @ManyToOne
	// @JoinColumn(name = "empId" )
	// private Employee employee;

}