package com.st.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityJwtApplication.class, args);
	}

	/*
	 * @Bean public OpenAPI customOpenAPI(@Value("${springdoc.version}") String
	 * appVersion) { return new OpenAPI() .components(new Components()) .info(new
	 * Info().title("Demo-IS Details API").version(appVersion) .license(new
	 * License().name("Apache 2.0").url("http://springdoc.org"))); }
	 */
}
