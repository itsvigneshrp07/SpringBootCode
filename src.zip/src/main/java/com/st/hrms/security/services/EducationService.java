package com.st.hrms.security.services;

import java.util.List;

import com.st.hrms.models.Education;

public interface EducationService {

	List<Education> getEducationDetails(String empId);

	Education updateEducation(Education education);

	void deleteEducation(long Id);
}
