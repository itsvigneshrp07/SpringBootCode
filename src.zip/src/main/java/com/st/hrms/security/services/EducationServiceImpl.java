package com.st.hrms.security.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.Education;
import com.st.hrms.repository.EducationRepository;

@Service
public class EducationServiceImpl implements EducationService {

	@Autowired
	private EducationRepository repo;

	@Override
	public List<Education> getEducationDetails(String empId) {
		return this.repo.findByEmployeeID(empId);
	}

	@Override
	public Education updateEducation(Education education) {
		Optional<Education> isDb = this.repo.findById(education.getId());
		if (isDb.isPresent()) {
			Education isUpdate = isDb.get();

			isUpdate.setId(education.getId());
			isUpdate.setEmployeeID(education.getEmployeeID());
			isUpdate.setLevel(education.getLevel());

			isUpdate.setBranch(education.getBranch());
			isUpdate.setSchool(education.getSchool());
			isUpdate.setUniversity(education.getUniversity());
			isUpdate.setPlace(education.getPlace());
			isUpdate.setState(education.getState());
			isUpdate.setCountry(education.getCountry());

			isUpdate.setYearOfPassing(education.getYearOfPassing());
			isUpdate.setPercentage(education.getPercentage());
			repo.save(isUpdate);
			return isUpdate;

		} else {
			throw new ResourceNotFoundException("Record not found with id : " + education.getId());
		}
	}

	@Override
	public void deleteEducation(long id) {
		Optional<Education> isDb = this.repo.findById(id);

		if (isDb.isPresent()) {
			this.repo.delete(isDb.get());
		} else {
			throw new ResourceNotFoundException("Record not found with id : " + id);
		}
	}

}
