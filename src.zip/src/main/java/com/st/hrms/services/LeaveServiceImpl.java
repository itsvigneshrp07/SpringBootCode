package com.st.hrms.services;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.hrms.models.LeaveBalance;
import com.st.hrms.models.LeaveDetails;
import com.st.hrms.models.LeaveMaster;
import com.st.hrms.repository.LeaveBalanceRepo;
import com.st.hrms.repository.LeaveDetailsRepo;
import com.st.hrms.repository.LeaveMasterRepo;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	LeaveDetailsRepo detailsRepo;

	@Autowired
	LeaveMasterRepo masterRepo;

	@Autowired
	LeaveBalanceRepo balanceRepo;

	@Override
	public List<LeaveBalance> getLeaveBalance() {
		return null;
	}

	public static long getDateDiff(final Date date1, final Date date2, final TimeUnit timeUnit) {
		long diffInMillies = date2.getTime() - date1.getTime();

		return timeUnit.convert(diffInMillies, timeUnit.MILLISECONDS);
	}

	@Override
	public List<LeaveBalance> getLeaveBalance(String empId, String startDate, String endDate) {
		// List<String> leaveTypes = LeaveType.getLeaveTypes();
		// LeaveBalance leaveBalance = new LeaveBalance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date sDate;

		List<LeaveBalance> leaveBalanceList = new ArrayList<LeaveBalance>();
		try {
			sDate = sdf.parse(startDate);
			java.sql.Date sqlStartDate = new java.sql.Date(sDate.getTime());
			sDate = sdf.parse(endDate);
			java.sql.Date sqlEndDate = new java.sql.Date(sDate.getTime());

			return balanceRepo.findCountByEmpIdSDateEDate(empId, sqlStartDate, sqlEndDate);

			/*
			 * for (String leaveType : leaveTypes) { leaveBalance =
			 * balanceRepo.findCountByEmpIdLeaveTypeSDateEDate(empId, leaveType,
			 * sqlStartDate, sqlEndDate); leaveBalanceList.add(leaveBalance); }
			 */
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return leaveBalanceList;

	}

	public void approveLeave(String empId) {
		List<LeaveDetails> leaveDetails = detailsRepo.getEmplLeaveDetails(empId, "APPLIED");
		for (LeaveDetails leaveDetail : leaveDetails) {
			int days = (int) getDateDiff(leaveDetail.getStartDate(), leaveDetail.getEndDate(), TimeUnit.DAYS) + 1;
			System.out.println("Leave Detail is : " + leaveDetail);
			LeaveBalance leaveBalance = balanceRepo.findCountByEmpIdLeaveType(leaveDetail.getEmpId(),
					leaveDetail.getLeaveType());
			System.out.println("leaveBalance data is " + leaveBalance);
			if (days <= leaveBalance.getCount()) {
				leaveDetail.setStatus("APPROVED");
				leaveDetail.setLocked(1);
				detailsRepo.save(leaveDetail);
				leaveBalance.setCount(leaveBalance.getCount() - days);
				leaveBalance.setLock(1);
				balanceRepo.save(leaveBalance);
			} else {
				leaveDetail.setStatus("REJECTED");
				detailsRepo.save(leaveDetail);
			}
		}
	}

	public void rejectLeave(String empId) {
		List<LeaveDetails> leaveDetails = detailsRepo.getEmplLeaveDetails(empId, "APPLIED");
		for (LeaveDetails leaveDetail : leaveDetails) {
			leaveDetail.setStatus("REJECTED");
			detailsRepo.save(leaveDetail);
		}
	}
	
	@Override
	public LeaveDetails applyLeave(LeaveDetails leaveDetail) {

		long days = getDateDiff(leaveDetail.getStartDate(), leaveDetail.getEndDate(), TimeUnit.DAYS) + 1;

		LeaveBalance balance = balanceRepo.findCountByEmpIdLeaveTypeSDateEDate(leaveDetail.getEmpId(),
				leaveDetail.getLeaveType(), leaveDetail.getStartDate(), leaveDetail.getEndDate());
		System.out.println("Leave Balance is : " + balance);
		if (days <= balance.getCount()) {
			leaveDetail.setStatus("APPLIED");
			return detailsRepo.save(leaveDetail);
		}
		return null;
	}



	public List<LeaveDetails> findByEmpId(String empId) {
		// System.out.println("Data from backend : "+detailsRepo.findByEmpId(empId));
		return detailsRepo.findByEmpId(empId);
	}

	
	@Override
	public List<LeaveMaster> getLeaveTypes(String startDate, String endDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date sDate;

		try {
			sDate = sdf.parse(startDate);
			java.sql.Date sqlStartDate = new java.sql.Date(sDate.getTime());
			sDate = sdf.parse(endDate);
			java.sql.Date sqlEndDate = new java.sql.Date(sDate.getTime());
			return masterRepo.getLeaveTypes(sqlStartDate, sqlEndDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;

	}
}
