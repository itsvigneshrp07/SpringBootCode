package com.st.hrms.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.Timesheet;
import com.st.hrms.repository.TimesheetRepository;

@Service
@Transactional

public class TimesheetServiceImpl implements TimesheetService {

	@Autowired
	private TimesheetRepository repo;

	@Override
	public List<Timesheet> findByEmpIdStartDateEndDATE(String empId, String startDate, String endDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date sDate;
		try {
			sDate = sdf.parse(startDate);

			java.sql.Date sqlStartDate = new java.sql.Date(sDate.getTime());
			sDate = sdf.parse(endDate);
			java.sql.Date sqlEndDate = new java.sql.Date(sDate.getTime());
			return repo.findByEmpIdStartDateEndDATE(empId, sqlStartDate, sqlEndDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Timesheet> createTimesheet(String inputData) {
		JSONObject jsonObj = new JSONObject(inputData);
		List<Timesheet> list = new ArrayList<Timesheet>();
		JSONObject json;
		Timesheet timesheetData = null;
		ObjectMapper objectMapper = new ObjectMapper();
		JSONArray jsonArray = jsonObj.getJSONArray("data");
		for (int i = 0; i < jsonArray.length(); i++) {
			json = jsonArray.getJSONObject(i);
			json.get("workDate");
			
			try {
				timesheetData = objectMapper.readValue(json.toString(), Timesheet.class);
				
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("data is : " + jsonArray.get(i));
			list.add(timesheetData);
		}

		return repo.saveAll(list);

		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); java.util.Date
		 * sDate; try { sDate = sdf.parse(String.valueOf(inputData.getWorkDate()));
		 * java.sql.Date sqlWorkDate = new java.sql.Date(sDate.getTime());
		 * inputData.setWorkDate(sqlWorkDate); return repo.save(inputData); } catch
		 * (ParseException e) { // TODO Auto-generated catch block e.printStackTrace();
		 * } return null;
		 */
	}

	@Override
	public Timesheet updateTimesheet(Timesheet id) {
		Optional<Timesheet> isDb = this.repo.findById(id.getId());
		if (isDb.isPresent()) {
			Timesheet isUpdate = isDb.get();
			isUpdate.setProjectName(id.getProjectName());
			isUpdate.setComment(id.getComment());
			isUpdate.setHours(id.getHours());
			isUpdate.setProjectId(id.getProjectId());
			isUpdate.setProjectName(id.getProjectName());
			isUpdate.setStatus(id.getStatus());
			isUpdate.setSubmittedDate(id.getSubmittedDate());
			isUpdate.setTaskId(id.getTaskId());
			isUpdate.setTaskName(id.getTaskName());
			isUpdate.setWorkDate(id.getWorkDate());
			repo.save(isUpdate);
			return isUpdate;
		} else {
			throw new ResourceNotFoundException("Record not found with id : " + id.getId());
		}
	}

}
