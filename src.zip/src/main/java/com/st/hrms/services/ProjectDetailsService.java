package com.st.hrms.services;

import java.util.List;

import com.st.hrms.models.ProjectDetails;

public interface ProjectDetailsService {

	List<ProjectDetails> createProjectDetails(String inputData);
	public ProjectDetails updateProjectDetails(ProjectDetails data);

}
