package com.st.hrms.services;

import java.util.List;

import com.st.hrms.models.Timesheet;

public interface TimesheetService {
	public List<Timesheet> findByEmpIdStartDateEndDATE(String empId, String startDate, String endDate);

	public List<Timesheet> createTimesheet(String inputData);

	public Timesheet updateTimesheet(Timesheet data);

}