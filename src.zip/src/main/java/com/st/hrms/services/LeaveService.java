package com.st.hrms.services;

import java.util.List;

import com.st.hrms.models.LeaveBalance;
import com.st.hrms.models.LeaveDetails;
import com.st.hrms.models.LeaveMaster;

public interface LeaveService {

	LeaveDetails applyLeave(LeaveDetails leaveDetails);

	List<LeaveDetails> findByEmpId(String empId);

	public List<LeaveBalance> getLeaveBalance();

	public List<LeaveBalance> getLeaveBalance(String empId, String startDate, String endDate);

	public void approveLeave(String empId);

	public void rejectLeave(String empId);
	
	List<LeaveMaster> getLeaveTypes(String startDate, String endDate);
}
