package com.st.hrms.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.ProjectDetails;
import com.st.hrms.repository.ProjectDetailsRepo;

@Service
@Transactional
public class ProjectDetailsServiceImpl implements ProjectDetailsService {

	@Autowired
	private ProjectDetailsRepo repo;

	@Override
	public List<ProjectDetails> createProjectDetails(String inputData) {
		JSONObject jsonObj = new JSONObject(inputData);
		List<ProjectDetails> list = new ArrayList<ProjectDetails>();
		JSONObject json;
		ProjectDetails ProjectDetailsData = null;
		ObjectMapper objectMapper = new ObjectMapper();
		JSONArray jsonArray = jsonObj.getJSONArray("data");
		for (int i = 0; i < jsonArray.length(); i++) {
			json = jsonArray.getJSONObject(i);
			try {
				ProjectDetailsData = objectMapper.readValue(json.toString(), ProjectDetails.class);
				list.add(ProjectDetailsData);
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("data is : " + jsonArray.get(i));
		}
		return repo.saveAll(list);

	}

	@Override
	public ProjectDetails updateProjectDetails(ProjectDetails projectDetails) {
		Optional<ProjectDetails> isDb = this.repo.findById(projectDetails.getId());
		if (isDb.isPresent()) {
			ProjectDetails projectDetail = isDb.get();
			projectDetail.setProjectName(projectDetails.getProjectName());
			projectDetail.setProjectId(projectDetails.getProjectId());
			projectDetail.setStatus(projectDetails.getStatus());
			projectDetail.setCreatedDate(projectDetails.getCreatedDate());
			projectDetail.setEndDate(projectDetails.getEndDate());
			projectDetail.setLeadName(projectDetails.getLeadName());
			projectDetail.setStartDate(projectDetails.getStartDate());
			repo.save(projectDetail);
			return projectDetail;
		} else {
			throw new ResourceNotFoundException("Record not found with id : " + projectDetails.getId());
		}
	}

}
