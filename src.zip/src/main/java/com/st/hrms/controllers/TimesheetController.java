package com.st.hrms.controllers;

import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.Timesheet;
import com.st.hrms.repository.TimesheetRepository;
import com.st.hrms.services.TimesheetService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "/api/v1")
public class TimesheetController {

	@Autowired
	private TimesheetService service;

	@Autowired
	private TimesheetRepository repo;

	@GetMapping("/timesheet/{id}")
	public ResponseEntity<Timesheet> getTimesheetById(@PathVariable(value = "id") Long id)
			throws ResourceNotFoundException {
		return ResponseEntity.ok().body(repo.getById(id));
	}

	@GetMapping("/timesheet/employee/{empId}")
	public ResponseEntity<List<Timesheet>> getTimesheetByEmpId(@PathVariable(value = "empId") String empId)
			throws ResourceNotFoundException {
		return ResponseEntity.ok().body(repo.findByEmpId(empId));
	}

	@GetMapping("/timesheet/{empId}/{startDate}/{endDate}")
	public ResponseEntity<List<Timesheet>> getTimesheetByEmpIdStartDateEndDate(
			@PathVariable(value = "empId") String empId, @PathVariable(value = "startDate") String startDate,
			@PathVariable(value = "endDate") String endDate) throws ResourceNotFoundException {
		return ResponseEntity.ok().body(service.findByEmpIdStartDateEndDATE(empId, startDate, endDate));
	}

	@GetMapping(path = "/timesheet/allEmployeeDetails")
	public ResponseEntity<List<Timesheet>> getAllEmployeeTimesheetDetails() {
		return ResponseEntity.ok().body(repo.findAll());
	}

	@PostMapping("/timesheet")
	public ResponseEntity<List<Timesheet>> createTimesheet(@RequestBody String inputData)
			throws JSONException, JSONException, JsonMappingException, JsonProcessingException {
		return ResponseEntity.ok().body(service.createTimesheet(inputData));
	}

	@PutMapping("/timesheet/{id}")
	public ResponseEntity<Timesheet> updateTimesheet(@PathVariable(value = "id") Long id, @RequestBody Timesheet data) {
		data.setId(id);
		return ResponseEntity.ok().body(this.service.updateTimesheet(data));
	}

	@DeleteMapping("/timesheet/{id}")
	public HttpStatus deleteTimesheet(@PathVariable(value = "id") Long id) {
		this.repo.deleteById(id);
		return HttpStatus.OK;
	}

	@DeleteMapping("/timesheet/employee/{empId}")
	public HttpStatus deleteTimesheetByEmpId(@PathVariable(value = "empId") String empId) {
		this.repo.deleteByEmpId(empId);
		return HttpStatus.OK;
	}

}