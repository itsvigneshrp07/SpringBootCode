
package com.st.hrms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.st.hrms.models.Education;
import com.st.hrms.repository.EducationRepository;
import com.st.hrms.security.services.EducationService;

@RestController

@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping(path = "api/v1")
public class EducationController {

	/*
	 * @Autowired private EducationService service;
	 * 
	 * @Autowired private EducationRepository repo;
	 * 
	 * @GetMapping(path = "/education") public ResponseEntity<List<Education>>
	 * getEducationDetails(@RequestParam String empId) { return
	 * ResponseEntity.ok().body(service.getEducationDetails(empId)); }
	 * 
	 * @PostMapping("/education") public ResponseEntity<Education>
	 * createEducation(@RequestBody Education education) { return
	 * ResponseEntity.ok().body(repo.save(education)); }
	 * 
	 * @PutMapping("/education/{id}") public ResponseEntity<Education>
	 * updateEducation(@PathVariable(value = "id") Long id,
	 * 
	 * @RequestBody Education education) { education.setId(id); return
	 * ResponseEntity.ok().body(this.service.updateEducation(education)); }
	 * 
	 * @DeleteMapping("/education/{id}") public HttpStatus
	 * deleteEducation(@PathVariable(value = "id") Long id) {
	 * this.service.deleteEducation(id); return HttpStatus.OK; }
	 */
}
