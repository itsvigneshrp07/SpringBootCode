package com.st.hrms.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.Address;
import com.st.hrms.models.BankDetails;
import com.st.hrms.models.Education;
import com.st.hrms.models.EmpDemographics;
import com.st.hrms.models.Employee;
import com.st.hrms.models.LanguageDetails;
import com.st.hrms.models.Workexperience;
import com.st.hrms.repository.AddressRepository;
import com.st.hrms.repository.BankRepository;
import com.st.hrms.repository.EducationRepository;
import com.st.hrms.repository.EmpDemographicsRepository;
import com.st.hrms.repository.EmployeeRepository;
import com.st.hrms.repository.LanguageDetailsRepository;
import com.st.hrms.repository.WorkexperienceRepository;
import com.st.hrms.security.services.EducationService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("addr")
public class ProfileController {

	@Autowired
	private AddressRepository addressRepository;
	@Autowired
	private BankRepository bankRepository;

	@Autowired
	private EmpDemographicsRepository demographicRepository;
	@Autowired
	private EmployeeRepository empRepo;
	@Autowired
	private LanguageDetailsRepository languageRepository;
	@Autowired
	private WorkexperienceRepository workRepository;
	@Autowired
	private EducationService educationservice;

	@Autowired
	private EducationRepository educationrepo;

	@PostMapping("/address")
	public Address addaddress(@Valid @RequestBody Address address) {
		return addressRepository.save(address);
	}

	@GetMapping(path = "/address")
	public List<Address> getAllAddressDetails() {
		return addressRepository.findAll();
	}

	@GetMapping("/address/{addid}")
	public ResponseEntity<Address> getAddressBroleIdById(@PathVariable(value = "addid") Long addressaddid)
			throws ResourceNotFoundException {
		Address address = addressRepository.findById(addressaddid).orElseThrow(
				() -> new ResourceNotFoundException("Address_Details not found for this addid:: " + addressaddid));
		return ResponseEntity.ok().body(address);
	}

	@PutMapping("/address/{addid}")
	public ResponseEntity<Address> updateaddressDetails(@PathVariable(value = "addid") Long addressaddid,
			@Valid @RequestBody Address addrDetails) throws ResourceNotFoundException {
		Address address = addressRepository.findById(addressaddid).orElseThrow(
				() -> new ResourceNotFoundException("Address details not found for this broleId :: " + addressaddid));

		address.setEmpId(addrDetails.getEmpId());
		address.setAddress_type(addrDetails.getAddress_type());
		address.setAddress1(addrDetails.getAddress1());
		address.setAddress2(addrDetails.getAddress2());
		address.setAddress3(addrDetails.getAddress3());
		address.setAddress4(addrDetails.getAddress4());
		address.setPlace(addrDetails.getPlace());
		address.setDistrict(addrDetails.getDistrict());
		address.setState(addrDetails.getState());
		address.setPincode(addrDetails.getPincode());
		address.setCountry(addrDetails.getCountry());

		final Address updateaddressDetails = addressRepository.save(address);
		return ResponseEntity.ok(updateaddressDetails);
	}

	@DeleteMapping("/address/{addid}")
	public Map<String, Boolean> deleteAddrDetails(@PathVariable(value = "addid") Long addressaddid)
			throws ResourceNotFoundException {
		Address address = addressRepository.findById(addressaddid).orElseThrow(
				() -> new ResourceNotFoundException("Address Details not found for this addid :: " + addressaddid));

		addressRepository.delete(address);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PostMapping("/Bank_D")
	public BankDetails addBank(@Valid @RequestBody BankDetails bank_B_details) {
		return bankRepository.save(bank_B_details);
	}

	@GetMapping(path = "/Bank_D")
	public List<BankDetails> getAllBankDetails() {
		return bankRepository.findAll();
	}

	@GetMapping("/Bank_D/{brole_id}")
	public ResponseEntity<BankDetails> getBankBroleIdById(@PathVariable(value = "brole_id") Long bank_B_detailsbrole_id)
			throws ResourceNotFoundException {
		BankDetails bank_B_details = bankRepository.findById(bank_B_detailsbrole_id)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Bank_Details not found for this broleId:: " + bank_B_detailsbrole_id));
		return ResponseEntity.ok().body(bank_B_details);
	}

	@PutMapping("/Bank_D/{brole_id}")
	public ResponseEntity<BankDetails> updateBankDetails(@PathVariable(value = "brole_id") Long bank_B_detailsbrole_id,
			@Valid @RequestBody BankDetails bankDetails) throws ResourceNotFoundException {
		BankDetails bank_B_details = bankRepository.findById(bank_B_detailsbrole_id)
				.orElseThrow(() -> new ResourceNotFoundException(
						"bank_B_details not found for this broleId :: " + bank_B_detailsbrole_id));

		bank_B_details.setEmpId(bankDetails.getEmpId());
		bank_B_details.setBank_name(bankDetails.getBank_name());
		bank_B_details.setBank_type(bankDetails.getBank_type());
		bank_B_details.setAcc_holdername(bankDetails.getAcc_holdername());
		bank_B_details.setAcc_no(bankDetails.getAcc_no());
		bank_B_details.setIfsc_code(bankDetails.getIfsc_code());
		bank_B_details.setBank_branch(bankDetails.getBank_branch());
		bank_B_details.setB_address(bankDetails.getB_address());
		bank_B_details.setPincode(bankDetails.getPincode());

		final BankDetails updateBankDetail = bankRepository.save(bank_B_details);
		return ResponseEntity.ok(updateBankDetail);
	}

	@DeleteMapping("/Bank_D/{brole_id}")
	public Map<String, Boolean> deleteBankDetails(@PathVariable(value = "brole_id") Long bank_B_detailsbrole_id)
			throws ResourceNotFoundException {
		BankDetails bank_B_details = bankRepository.findById(bank_B_detailsbrole_id)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Bank Details not found for this broleId :: " + bank_B_detailsbrole_id));

		bankRepository.delete(bank_B_details);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PostMapping("/EmpDemographics")
	public EmpDemographics addEmployee(@Valid @RequestBody EmpDemographics empdemographics) {
		return demographicRepository.save(empdemographics);
	}

	@GetMapping(path = "/EmpDemographics")
	public List<EmpDemographics> getAllEmployees() {
		return demographicRepository.findAll();
	}

	@GetMapping("/EmpDemographics/{Id}")
	public ResponseEntity<EmpDemographics> getEmployeeById(@PathVariable(value = "Id") Long empdemographicsId)
			throws ResourceNotFoundException {
		EmpDemographics empdemographics = demographicRepository.findById(empdemographicsId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"empdemographics details not found for this Id:: " + empdemographicsId));
		return ResponseEntity.ok().body(empdemographics);
	}

	@PutMapping("/EmpDemographics/{Id}")
	public ResponseEntity<EmpDemographics> updateEmployee(@PathVariable(value = "Id") Long empdemographicsId,
			@Valid @RequestBody EmpDemographics empdemographicsDetails) throws ResourceNotFoundException {
		EmpDemographics empdemographics = demographicRepository.findById(empdemographicsId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"empdemographics details not found for this Id :: " + empdemographicsId));

		empdemographics.setEmpId(empdemographicsDetails.getEmpId());
		empdemographics.setF_name(empdemographicsDetails.getF_name());
		empdemographics.setM_name(empdemographicsDetails.getM_name());
		empdemographics.setL_name(empdemographicsDetails.getL_name());
		empdemographics.setDepartment(empdemographicsDetails.getDepartment());

		empdemographics.setPersonal_mobile_no(empdemographicsDetails.getPersonal_mobile_no());
		empdemographics.setPlace_Of_Birth(empdemographicsDetails.getPlace_Of_Birth());
		empdemographics.setAdhar_no(empdemographicsDetails.getAdhar_no());
		empdemographics.setPan_no(empdemographicsDetails.getPan_no());
		empdemographics.setPassPort_no(empdemographicsDetails.getPassPort_no());
		empdemographics.setPersonal_email(empdemographicsDetails.getPersonal_email());
		empdemographics.setGender(empdemographicsDetails.getGender());
		empdemographics.setReligion(empdemographicsDetails.getReligion());
		empdemographics.setMarital_Status(empdemographicsDetails.getMarital_Status());
		empdemographics.setBloodgroup(empdemographicsDetails.getBloodgroup());
		empdemographics.setActive(true);

		final EmpDemographics updatedEmployee = demographicRepository.save(empdemographics);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/EmpDemographics/{Id}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "Id") Long empdemographicsId)
			throws ResourceNotFoundException {
		EmpDemographics empdemographics = demographicRepository.findById(empdemographicsId)
				.orElseThrow(() -> new ResourceNotFoundException(
						"empdemographics details not found for this Id :: " + empdemographicsId));

		demographicRepository.delete(empdemographics);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PostMapping("/employees")
	public Employee addEmployee(@Valid @RequestBody Employee employee) {
		return empRepo.save(employee);
	}

	@GetMapping(path = "/employees")
	public List<Employee> getAllEmployees1() {
		return empRepo.findAll();
	}

	@GetMapping("/employees/{EmpId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "EmpId") String employeeEmpId)
			throws ResourceNotFoundException {
		Employee employee = empRepo.findById(employeeEmpId).orElseThrow(
				() -> new ResourceNotFoundException("Employee not found for this EmpId:: " + employeeEmpId));
		return ResponseEntity.ok().body(employee);
	}

	@PutMapping("/employees/{EmpId}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "EmpId") String employeeEmpId,
			@Valid @RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		Employee employee = empRepo.findById(employeeEmpId).orElseThrow(
				() -> new ResourceNotFoundException("Employee not found for this EmpId :: " + employeeEmpId));

		// employee.setOrgId(employeeDetails.getOrgId());
		employee.setDate_of_joining(employeeDetails.getDate_of_joining());
		employee.setDepartment(employeeDetails.getDepartment());
		employee.setFname(employeeDetails.getFname());
		employee.setMname(employeeDetails.getMname());
		employee.setLname(employeeDetails.getLname());
		employee.setGender(employeeDetails.getGender());
		employee.setDateofbirth(employeeDetails.getDateofbirth());
		employee.setOfficial_email(employeeDetails.getOfficial_email());
		employee.setPersonal_email(employeeDetails.getPersonal_email());
		employee.setOfficial_mobile_no(employeeDetails.getOfficial_mobile_no());
		employee.setPersonal_mobile_no(employeeDetails.getPersonal_mobile_no());
		// employee.setWorkExperience(employeeDetails.getWorkExperience());
//	        employee.setSalary(employeeDetails.getSalary());
		// employee.setCompany(employeeDetails.getCompany());
		employee.setActive(true);

		final Employee updatedEmployee = empRepo.save(employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employees/{EmpId}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "EmpId") String employeeEmpId)
			throws ResourceNotFoundException {
		Employee employee = empRepo.findById(employeeEmpId).orElseThrow(
				() -> new ResourceNotFoundException("Employee not found for this EmpId :: " + employeeEmpId));

		empRepo.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PostMapping("/language")
	public LanguageDetails addlang(@Valid @RequestBody LanguageDetails language_details) {
		return languageRepository.save(language_details);
	}

	@GetMapping(path = "/language")
	public List<LanguageDetails> getAlllangDetails() {
		return languageRepository.findAll();
	}

	@GetMapping("/language/{id}")
	public ResponseEntity<LanguageDetails> getlangIdById(@PathVariable(value = "id") Long language_detailsid)
			throws ResourceNotFoundException {
		LanguageDetails language_details = languageRepository.findById(language_detailsid).orElseThrow(
				() -> new ResourceNotFoundException("language_details not found for this Id:: " + language_detailsid));
		return ResponseEntity.ok().body(language_details);
	}

	@PutMapping("/language/{id}")
	public ResponseEntity<LanguageDetails> updatelangsDetails(@PathVariable(value = "id") Long language_detailsid,
			@Valid @RequestBody LanguageDetails langDetails) throws ResourceNotFoundException {
		LanguageDetails language_details = languageRepository.findById(language_detailsid)
				.orElseThrow(() -> new ResourceNotFoundException(
						"language_details details not found for this Id :: " + language_detailsid));

		language_details.setEmpId(langDetails.getEmpId());
		language_details.setLan_name1(langDetails.getLan_name1());
		language_details.setLan_name2(langDetails.getLan_name2());
		language_details.setLan_name3(langDetails.getLan_name3());
		language_details.setMothertongue(langDetails.getMothertongue());
		language_details.setSpeakks1(langDetails.getSpeakks1());
		language_details.setSpeakks2(langDetails.getSpeakks2());
		language_details.setSpeakks3(langDetails.getSpeakks3());

		language_details.setWritees1(langDetails.getWritees1());
		language_details.setWritees2(langDetails.getWritees2());
		language_details.setWritees3(langDetails.getWritees3());
		language_details.setReadds1(langDetails.getReadds1());
		language_details.setReadds2(langDetails.getReadds2());
		language_details.setReadds3(langDetails.getReadds3());

		final LanguageDetails updatelangsDetails = languageRepository.save(language_details);
		return ResponseEntity.ok(updatelangsDetails);
	}

	@DeleteMapping("/language/{id}")
	public Map<String, Boolean> deletelangDetails(@PathVariable(value = "id") Long language_detailsid)
			throws ResourceNotFoundException {
		LanguageDetails language_details = languageRepository.findById(language_detailsid)
				.orElseThrow(() -> new ResourceNotFoundException(
						"language_details Details not found for this Id :: " + language_detailsid));

		languageRepository.delete(language_details);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@PostMapping("/workexperience")
	public Workexperience workexperience(@Valid @RequestBody Workexperience workexperience) {
		return workRepository.save(workexperience);
	}

	@GetMapping(path = "/workexperience")
	public List<Workexperience> getAllWorkexpDetails() {
		return workRepository.findAll();
	}

	@GetMapping("/workexperience/{id}")
	public ResponseEntity<Workexperience> getworkexpBroleIdById(@PathVariable(value = "id") Long Workexperienceid)
			throws ResourceNotFoundException {
		Workexperience workexperience = workRepository.findById(Workexperienceid).orElseThrow(
				() -> new ResourceNotFoundException("Workexperience not found for this Id:: " + Workexperienceid));
		return ResponseEntity.ok().body(workexperience);
	}

	@PutMapping("/workexperience/{id}")
	public ResponseEntity<Workexperience> updateaworkexpDetails(@PathVariable(value = "id") Long Workexperienceid,
			@Valid @RequestBody Workexperience workDetails) throws ResourceNotFoundException {
		Workexperience workexperience = workRepository.findById(Workexperienceid)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Workexperience details not found for this Id :: " + Workexperienceid));

		workexperience.setEmpId(workDetails.getEmpId());
		workexperience.setTotal_workexperience(workDetails.getTotal_workexperience());
		workexperience.setOrg_name1(workDetails.getOrg_name1());
		workexperience.setOrg_name2(workDetails.getOrg_name2());
		workexperience.setOrg_name3(workDetails.getOrg_name3());
		workexperience.setReference_name(workDetails.getReference_name());
		workexperience.setReference_name1(workDetails.getReference_name1());
		workexperience.setReference_name2(workDetails.getReference_name2());
		workexperience.setReference_email(workDetails.getReference_email());
		workexperience.setReference_email1(workDetails.getReference_email1());
		workexperience.setReference_email2(workDetails.getReference_email2());
		workexperience.setReference_contact(workDetails.getReference_contact());
		workexperience.setReference_contact1(workDetails.getReference_contact1());
		workexperience.setReference_contact3(workDetails.getReference_contact3());
		workexperience.setFrom_joining_date(workDetails.getFrom_joining_date());
		workexperience.setFrom_end_date(workDetails.getFrom_end_date());
		workexperience.setDesignation(workDetails.getDesignation());
		workexperience.setCtc(workDetails.getCtc());
		workexperience.setReason_of_leaving(workDetails.getReason_of_leaving());

		final Workexperience updateaworkexpDetails = workRepository.save(workexperience);
		return ResponseEntity.ok(updateaworkexpDetails);
	}

	@DeleteMapping("/workexperience/{id}")
	public Map<String, Boolean> deleteworkDetails(@PathVariable(value = "id") Long Workexperienceid)
			throws ResourceNotFoundException {
		Workexperience workexperience = workRepository.findById(Workexperienceid)
				.orElseThrow(() -> new ResourceNotFoundException(
						"Workexperience Details not found for this Id :: " + Workexperienceid));

		workRepository.delete(workexperience);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@GetMapping(path = "/education")
	public ResponseEntity<List<Education>> getEducationDetails(@RequestParam String empId) {
		return ResponseEntity.ok().body(educationservice.getEducationDetails(empId));
	}

	@PostMapping("/education")
	public ResponseEntity<Education> createEducation(@RequestBody Education education) {
		return ResponseEntity.ok().body(educationrepo.save(education));
	}

	@PutMapping("/education/{id}")
	public ResponseEntity<Education> updateEducation(@PathVariable(value = "id") Long id,

			@RequestBody Education education) {
		education.setId(id);
		return ResponseEntity.ok().body(this.educationservice.updateEducation(education));
	}

	@DeleteMapping("/education/{id}")
	public HttpStatus deleteEducation(@PathVariable(value = "id") Long id) {
		this.educationservice.deleteEducation(id);
		return HttpStatus.OK;
	}
}
