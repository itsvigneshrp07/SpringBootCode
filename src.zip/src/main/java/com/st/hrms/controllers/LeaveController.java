package com.st.hrms.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.LeaveBalance;
import com.st.hrms.models.LeaveDetails;
import com.st.hrms.models.LeaveMaster;
import com.st.hrms.repository.LeaveBalanceRepo;
import com.st.hrms.repository.LeaveDetailsRepo;
import com.st.hrms.repository.LeaveMasterRepo;
import com.st.hrms.services.LeaveService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class LeaveController {

	@Autowired
	LeaveService service;

	@Autowired
	LeaveDetailsRepo detailsRepo;

	@Autowired
	private LeaveMasterRepo masterRepo;

	@Autowired
	private LeaveBalanceRepo balanceRepo;

	@PostMapping("/applyLeave")
	public ResponseEntity<LeaveDetails> applyLeave(@RequestBody LeaveDetails details) {
		// return leaveRepository.save(details);
		System.out.println("Leave Details : " + details);
		// return detailsService.applyLeave(details);
		return new ResponseEntity<>(service.applyLeave(details), HttpStatus.OK);

	}

	@PostMapping("/createLeaveMaster")
	public LeaveMaster createLeaveMaster(@RequestBody LeaveMaster master) {
		System.out.println("Inside the create Leave master");
		LeaveBalance leaveBalance = new LeaveBalance();
		leaveBalance.setEmpId("1234");
		leaveBalance.setLeaveType(master.getLeaveType());
		leaveBalance.setStartDate(master.getStartDate());
		leaveBalance.setEndDate(master.getEndDate());
		leaveBalance.setCount(master.getCount());
		balanceRepo.save(leaveBalance);
		return masterRepo.save(master);
	}

	@GetMapping("/leaveBalance")
	public List<LeaveBalance> getLeaveBalanceBy(String empId, String startDate, String endDate) {

		System.out.println("DAta from UI is " + startDate + " **** " + endDate);

		return service.getLeaveBalance(empId, startDate, endDate);
	}

	@GetMapping("/leaveDetails")
	public ResponseEntity<List<LeaveDetails>> getLeaveDetails(@RequestParam String empId) {

		System.out.println("Employee Id from UI is : " + empId);
		return new ResponseEntity<>(service.findByEmpId(empId), HttpStatus.OK);
	}

	@DeleteMapping("/deleteLeaveDetails")
	public ResponseEntity<Map<String, Boolean>> deleteLeaveDetails(@RequestParam Long id) {
		LeaveDetails leaveDetail = detailsRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Data does not exist with id :" + id));
		detailsRepo.delete(leaveDetail);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted the Record", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/approveLeave")
	public void approveLeave(String empId) {
		service.approveLeave(empId);
	}

	@GetMapping("/rejectLeave")
	public void rejectLeave(String empId) {
		service.rejectLeave(empId);
	}

	@GetMapping("/getLeaveTypes")
	public ResponseEntity<List<LeaveMaster>> getLeaveTypes(String startDate, String endDate) {
		return new ResponseEntity<>(service.getLeaveTypes(startDate, endDate), HttpStatus.OK);
	}
}