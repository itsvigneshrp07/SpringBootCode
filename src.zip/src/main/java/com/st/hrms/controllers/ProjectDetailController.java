package com.st.hrms.controllers;

import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.st.hrms.exception.ResourceNotFoundException;
import com.st.hrms.models.ProjectDetails;
import com.st.hrms.repository.ProjectDetailsRepo;
import com.st.hrms.services.ProjectDetailsService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "/api/v1")
public class ProjectDetailController {

	@Autowired
	ProjectDetailsRepo repo;

	@Autowired
	ProjectDetailsService service;

	@GetMapping("/projectDetails")
	public ResponseEntity<List<ProjectDetails>> getAllProjectDetails() {
		return ResponseEntity.ok().body(repo.findAll());
	}

	@GetMapping("/projectDetailsById/{projectId}")
	public ResponseEntity<ProjectDetails> getProjectDetailsById(@PathVariable(value = "projectId") String projectId)
			throws ResourceNotFoundException {
		return ResponseEntity.ok().body(repo.findByProjectId(projectId));
	}

	@GetMapping("/projectDetailsByName/{projectName}")
	public ResponseEntity<ProjectDetails> getProjectDetailsByProjectName(
			@PathVariable(value = "projectName") String projectName) throws ResourceNotFoundException {
		return ResponseEntity.ok().body(repo.findByProjectName(projectName));
	}

	@PostMapping("/projectDetails")
	public ResponseEntity<List<ProjectDetails>> createProjectDetails(@RequestBody String inputData)
			throws JSONException, JSONException, JsonMappingException, JsonProcessingException {
		return ResponseEntity.ok().body(service.createProjectDetails(inputData));
	}
	
	@PutMapping("/projectDetails/{id}")
	public ResponseEntity<ProjectDetails> updateProjectDetails(@PathVariable(value = "id") Long id,
			@RequestBody ProjectDetails data) {
		data.setId(id);
		return ResponseEntity.ok().body(this.service.updateProjectDetails(data));
	}

	@DeleteMapping("/projectDetails/{id}")
	public HttpStatus deleteProjectDetails(@PathVariable(value = "id") Long id) {
		this.repo.deleteById(id);
		return HttpStatus.OK;
	}

	@DeleteMapping("/projectDetails/project/{empId}")
	public HttpStatus deleteProjectDetailsByProjectId(@PathVariable(value = "projectId") String projectId) {
		this.repo.deleteByProjectId(projectId);
		return HttpStatus.OK;
	}

}